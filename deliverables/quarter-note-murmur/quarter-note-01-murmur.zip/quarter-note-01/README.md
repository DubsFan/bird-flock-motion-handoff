# Quarter Note — Beat Bop

Import the parent `quarter-note-01-murmur.zip` into one Murmur Flock tab. The archive contains exactly one `manifest.json`, eight chronological flight PNGs, and three matched eight-frame action tracks.

Expected import result:

`Passed: 8 flight poses plus 24 matched landing-action poses. Murmur will switch tracks automatically.`

The fixed notehead anchor is `(800, 900)` on every 1600 × 1200 frame. All visible pixels use `#0D8EEB`; background pixels are straight alpha with RGB zero.
